# vrp_yorkcaixa
Roubo ao caixa eletrônico feito para o FiveM, voltado a vRPex

Coloque os dois áudios (.ogg) dentro de vrp_sounds\html\sounds. 
